# Projet_CA

Le compilateur est implémenté dans le dossier dans le dossier projet-compil-21-22/compiler.

Le bytecode généré par le compilateur se trouve dans le fichier projet-compil-21-22/bytecode/byte.txt

Nous avons ajouté des tests pour tester notre implementation et nos extensions dans le dossier projet-compil-21-22/nosTests.


Dans le repertoire projet-compil-21-22/ :

Pour compiler la vm ainsi que le compilateur  ->  make 

Pour lancer tous les tests du dossier /tests  ->  make runtest

Pour lancer tous les tests que nous avons ajouté  ->  make runnostest