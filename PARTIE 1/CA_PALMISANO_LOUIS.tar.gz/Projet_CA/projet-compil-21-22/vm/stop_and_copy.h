#ifndef _STOP_AND_COPY_H
#define _STOP_AND_COPY_H

#include "mlvalues.h"

mlvalue *stop_and_copy_alloc(size_t n);

#endif /* _STOP_AND_COPY_H */
