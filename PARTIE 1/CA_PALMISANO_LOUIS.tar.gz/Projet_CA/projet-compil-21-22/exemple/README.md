$ vm/minizam exemple/demo-bytecode.txt
42
12
$