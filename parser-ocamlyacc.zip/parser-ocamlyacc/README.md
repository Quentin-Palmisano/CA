

```bash
$ make
$ ./eval tests/e1.txt
(((1 + 2) + 3) + 4)
~> 10
$ make clean
```